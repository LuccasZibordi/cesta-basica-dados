# Modelo institucional preservado

Arquivo: `2s2026_Modelo_Relatorio_Curricularizacao_Extensao_PROGRAD.docx`.

Recebido de Luccas em 25/11/2026, origem `/home/luccas/Downloads/2s2026_Modelo_Relatorio_Curricularizacao_Extensao_PROGRAD.docx`. Cópia byte a byte; SHA-256:

`db48fca45ed0dcb40a0f5c9c50eed8dd9873f0a818645fa26f3f342ae2e9d4dd`

Instrução explícita do usuário: **não elaborar os relatórios individuais ainda; apenas guardar o modelo**. O arquivo original e a cópia não foram editados. Sua leitura detalhada e preenchimento ficam para a etapa futura autorizada. Não há relatórios individuais produzidos nesta entrega.
